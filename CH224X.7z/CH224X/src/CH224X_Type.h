#pragma once
#include <Arduino.h>

enum CH224_Chip_Type {
  CH224_AQ,  // For CH224A and CH224Q
  CH224_K    // For CH224K
};

